import React from 'react'

const Item = ({obj,fn}) => {
  return (
    <figure onClick={detail}>
        <p><img src={obj.photo} /></p>
        <figcaption>
            <p>{obj.title}</p>
            <code>${obj.price}</code>
        </figcaption>
    </figure>
  )
}

export default Item