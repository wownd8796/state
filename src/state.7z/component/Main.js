import React from 'react'

const Main = () => {
  return (
    <h1>React State & Props</h1>
  )
}

export default Main