import React from 'react'
import p_data from '../data/p_data.json';

const Product = () => {
  return (
    <article className='list'>
        <h2>Product</h2>
        <div>
            <figure >
                <p><img src="./img/01.jpg" /></p>
                <figcaption>
                    <p>adidas stan smith1</p>
                    <code>$160</code>
                </figcaption>
            </figure>
            <figure >
                <p><img src="./img/01.jpg" /></p>
                <figcaption>
                    <p>adidas stan smith1</p>
                    <code>$160</code>
                </figcaption>
            </figure>
            <figure >
                <p><img src="./img/01.jpg" /></p>
                <figcaption>
                    <p>adidas stan smith1</p>
                    <code>$160</code>
                </figcaption>
            </figure>
            <figure >
                <p><img src="./img/01.jpg" /></p>
                <figcaption>
                    <p>adidas stan smith1</p>
                    <code>$160</code>
                </figcaption>
            </figure>
            <figure >
                <p><img src="./img/01.jpg" /></p>
                <figcaption>
                    <p>adidas stan smith1</p>
                    <code>$160</code>
                </figcaption>
            </figure>
            
        </div>
    </article>
  )
}

export default Product