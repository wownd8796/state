import './css/common.scss';
import {BrowserRouter, Routes, Route, Link} from 'react-router-dom';
import Main from './component/Main';
import Product from './component/Product';

function App() {
  return (
    <BrowserRouter>
      <header>
        <Link to="/" className='active'>HOME</Link>
        <Link to="/product" >Product</Link>
      </header>
      <main>
        <Routes>
          <Route path='/' element={<Main/>}/>
          <Route path='/product' element={<Product/>}/>
        </Routes>
      </main>
    </BrowserRouter>
  );
}

export default App;
